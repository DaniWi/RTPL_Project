/* sscc : C CODE OF SORTED EQUATIONS Esterel_Dining_Phil - INLINE MODE */

/* AUXILIARY DECLARATIONS */

#ifndef STRLEN
#define STRLEN 81
#endif
#define _COND(A,B,C) ((A)?(B):(C))
#ifdef TRACE_ACTION
#include <stdio.h>
#endif
#ifndef NULL
#define NULL ((char*)0)
#endif

#ifndef __EXEC_STATUS_H_LOADED
#define __EXEC_STATUS_H_LOADED

typedef struct {
unsigned int start:1;
unsigned int kill:1;
unsigned int active:1;
unsigned int suspended:1;
unsigned int prev_active:1;
unsigned int prev_suspended:1;
unsigned int exec_index;
unsigned int task_exec_index;
void (*pStart)();
void (*pRet)();
} __ExecStatus;

#endif
#define __ResetExecStatus(status) {\
   status.prev_active = status.active; \
   status.prev_suspended = status.suspended; \
   status.start = status.kill = status.active = status.suspended = 0; }
#define __DSZ(V) (--(V)<=0)
#define BASIC_TYPES_DEFINED
typedef int boolean;
typedef int integer;
typedef char* string;
#define _true 1
#define _false 0
#define __Esterel_Dining_Phil_GENERIC_TEST(TEST) return TEST;
typedef void (*__Esterel_Dining_Phil_APF)();
static __Esterel_Dining_Phil_APF *__Esterel_Dining_Phil_PActionArray;

                                 
/* EXTERN DECLARATIONS */

#ifndef _NO_EXTERN_DEFINITIONS
#endif

/* INITIALIZED CONSTANTS */

/* MEMORY ALLOCATION */

static integer __Esterel_Dining_Phil_V0;
static boolean __Esterel_Dining_Phil_V1;
static integer __Esterel_Dining_Phil_V2;
static integer __Esterel_Dining_Phil_V3;
static integer __Esterel_Dining_Phil_V4;
static integer __Esterel_Dining_Phil_V5;
static integer __Esterel_Dining_Phil_V6;


/* INPUT FUNCTIONS */


/* ACTIONS */

/* PREDEFINED ACTIONS */

/* PRESENT SIGNAL TESTS */

/* OUTPUT ACTIONS */

#define __Esterel_Dining_Phil_A1 \
Esterel_Dining_Phil_O_FORKS_USED(__Esterel_Dining_Phil_V0)
#define __Esterel_Dining_Phil_A2 \
Esterel_Dining_Phil_O_FORK1()
#define __Esterel_Dining_Phil_A3 \
Esterel_Dining_Phil_O_FORK2()
#define __Esterel_Dining_Phil_A4 \
Esterel_Dining_Phil_O_FORK3()
#define __Esterel_Dining_Phil_A5 \
Esterel_Dining_Phil_O_FORK4()
#define __Esterel_Dining_Phil_A6 \
Esterel_Dining_Phil_O_FORK5()
#define __Esterel_Dining_Phil_A7 \
Esterel_Dining_Phil_O_WAIT1()
#define __Esterel_Dining_Phil_A8 \
Esterel_Dining_Phil_O_WAIT2()
#define __Esterel_Dining_Phil_A9 \
Esterel_Dining_Phil_O_WAIT3()
#define __Esterel_Dining_Phil_A10 \
Esterel_Dining_Phil_O_WAIT4()
#define __Esterel_Dining_Phil_A11 \
Esterel_Dining_Phil_O_WAIT5()
#define __Esterel_Dining_Phil_A12 \
Esterel_Dining_Phil_O_THINK1()
#define __Esterel_Dining_Phil_A13 \
Esterel_Dining_Phil_O_THINK2()
#define __Esterel_Dining_Phil_A14 \
Esterel_Dining_Phil_O_THINK3()
#define __Esterel_Dining_Phil_A15 \
Esterel_Dining_Phil_O_THINK4()
#define __Esterel_Dining_Phil_A16 \
Esterel_Dining_Phil_O_THINK5()
#define __Esterel_Dining_Phil_A17 \
Esterel_Dining_Phil_O_EAT1()
#define __Esterel_Dining_Phil_A18 \
Esterel_Dining_Phil_O_EAT2()
#define __Esterel_Dining_Phil_A19 \
Esterel_Dining_Phil_O_EAT3()
#define __Esterel_Dining_Phil_A20 \
Esterel_Dining_Phil_O_EAT4()
#define __Esterel_Dining_Phil_A21 \
Esterel_Dining_Phil_O_EAT5()
#define __Esterel_Dining_Phil_A22 \
Esterel_Dining_Phil_O_REQUEST_WAITER1()
#define __Esterel_Dining_Phil_A23 \
Esterel_Dining_Phil_O_REQUEST_WAITER2()
#define __Esterel_Dining_Phil_A24 \
Esterel_Dining_Phil_O_REQUEST_WAITER3()
#define __Esterel_Dining_Phil_A25 \
Esterel_Dining_Phil_O_REQUEST_WAITER4()
#define __Esterel_Dining_Phil_A26 \
Esterel_Dining_Phil_O_REQUEST_WAITER5()
#define __Esterel_Dining_Phil_A27 \
Esterel_Dining_Phil_O_PERMISSION_WAITER1()
#define __Esterel_Dining_Phil_A28 \
Esterel_Dining_Phil_O_PERMISSION_WAITER2()
#define __Esterel_Dining_Phil_A29 \
Esterel_Dining_Phil_O_PERMISSION_WAITER3()
#define __Esterel_Dining_Phil_A30 \
Esterel_Dining_Phil_O_PERMISSION_WAITER4()
#define __Esterel_Dining_Phil_A31 \
Esterel_Dining_Phil_O_PERMISSION_WAITER5()
#define __Esterel_Dining_Phil_A32 \
Esterel_Dining_Phil_O_DEADLOCK()
#define __Esterel_Dining_Phil_A33 \
Esterel_Dining_Phil_O_FORK1_DOUBLE()
#define __Esterel_Dining_Phil_A34 \
Esterel_Dining_Phil_O_FORK2_DOUBLE()
#define __Esterel_Dining_Phil_A35 \
Esterel_Dining_Phil_O_FORK3_DOUBLE()
#define __Esterel_Dining_Phil_A36 \
Esterel_Dining_Phil_O_FORK4_DOUBLE()
#define __Esterel_Dining_Phil_A37 \
Esterel_Dining_Phil_O_FORK5_DOUBLE()
#define __Esterel_Dining_Phil_A38 \
Esterel_Dining_Phil_O_P1OK()
#define __Esterel_Dining_Phil_A39 \
Esterel_Dining_Phil_O_P2OK()
#define __Esterel_Dining_Phil_A40 \
Esterel_Dining_Phil_O_P3OK()
#define __Esterel_Dining_Phil_A41 \
Esterel_Dining_Phil_O_P4OK()
#define __Esterel_Dining_Phil_A42 \
Esterel_Dining_Phil_O_P5OK()
#define __Esterel_Dining_Phil_A43 \
Esterel_Dining_Phil_O_P1WAIT25CYCLES()
#define __Esterel_Dining_Phil_A44 \
Esterel_Dining_Phil_O_P2WAIT25CYCLES()
#define __Esterel_Dining_Phil_A45 \
Esterel_Dining_Phil_O_P3WAIT25CYCLES()
#define __Esterel_Dining_Phil_A46 \
Esterel_Dining_Phil_O_P4WAIT25CYCLES()
#define __Esterel_Dining_Phil_A47 \
Esterel_Dining_Phil_O_P5WAIT25CYCLES()

/* ASSIGNMENTS */

#define __Esterel_Dining_Phil_A48 \
__Esterel_Dining_Phil_V1 = _false
#define __Esterel_Dining_Phil_A49 \
__Esterel_Dining_Phil_V0 = 0
#define __Esterel_Dining_Phil_A50 \
__Esterel_Dining_Phil_V0 = _COND(__Esterel_Dining_Phil_V1,(__Esterel_Dining_Phil_V0+(1)),(__Esterel_Dining_Phil_V1=_true,1))
#define __Esterel_Dining_Phil_A51 \
__Esterel_Dining_Phil_V0 = _COND(__Esterel_Dining_Phil_V1,(__Esterel_Dining_Phil_V0+(1)),(__Esterel_Dining_Phil_V1=_true,1))
#define __Esterel_Dining_Phil_A52 \
__Esterel_Dining_Phil_V0 = _COND(__Esterel_Dining_Phil_V1,(__Esterel_Dining_Phil_V0+(1)),(__Esterel_Dining_Phil_V1=_true,1))
#define __Esterel_Dining_Phil_A53 \
__Esterel_Dining_Phil_V0 = _COND(__Esterel_Dining_Phil_V1,(__Esterel_Dining_Phil_V0+(1)),(__Esterel_Dining_Phil_V1=_true,1))
#define __Esterel_Dining_Phil_A54 \
__Esterel_Dining_Phil_V0 = _COND(__Esterel_Dining_Phil_V1,(__Esterel_Dining_Phil_V0+(1)),(__Esterel_Dining_Phil_V1=_true,1))
#define __Esterel_Dining_Phil_A55 \
__Esterel_Dining_Phil_V0 = _COND(__Esterel_Dining_Phil_V1,(__Esterel_Dining_Phil_V0+(0)),(__Esterel_Dining_Phil_V1=_true,0))
#define __Esterel_Dining_Phil_A56 \
__Esterel_Dining_Phil_V2 = 24
#define __Esterel_Dining_Phil_A57 \
__Esterel_Dining_Phil_V3 = 24
#define __Esterel_Dining_Phil_A58 \
__Esterel_Dining_Phil_V4 = 24
#define __Esterel_Dining_Phil_A59 \
__Esterel_Dining_Phil_V5 = 24
#define __Esterel_Dining_Phil_A60 \
__Esterel_Dining_Phil_V6 = 24

/* PROCEDURE CALLS */

/* CONDITIONS */

/* DECREMENTS */

#define __Esterel_Dining_Phil_A61 \
__DSZ(__Esterel_Dining_Phil_V2)
#define __Esterel_Dining_Phil_A62 \
__DSZ(__Esterel_Dining_Phil_V3)
#define __Esterel_Dining_Phil_A63 \
__DSZ(__Esterel_Dining_Phil_V4)
#define __Esterel_Dining_Phil_A64 \
__DSZ(__Esterel_Dining_Phil_V5)
#define __Esterel_Dining_Phil_A65 \
__DSZ(__Esterel_Dining_Phil_V6)

/* START ACTIONS */

/* KILL ACTIONS */

/* SUSPEND ACTIONS */

/* ACTIVATE ACTIONS */

/* WRITE ARGS ACTIONS */

/* RESET ACTIONS */

/* ACTION SEQUENCES */

/* FUNCTIONS RETURNING NUMBER OF EXEC */

int Esterel_Dining_Phil_number_of_execs () {
return (0);
}


/* AUTOMATON (STATE ACTION-TREES) */



static void __Esterel_Dining_Phil__reset_input () {
__Esterel_Dining_Phil_V1 = _false;
}

/* REDEFINABLE BIT TYPE */

#ifndef __SSC_BIT_TYPE_DEFINED
typedef char __SSC_BIT_TYPE;
#endif

/* REGISTER VARIABLES */

static __SSC_BIT_TYPE __Esterel_Dining_Phil_R[91] = {_true,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false,
 _false};

/* AUTOMATON ENGINE */

int Esterel_Dining_Phil () {
/* AUXILIARY VARIABLES */

static __SSC_BIT_TYPE E[175];
if (__Esterel_Dining_Phil_R[0]) {
__Esterel_Dining_Phil_A49;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A49\n");
#endif
}
E[0] = (__Esterel_Dining_Phil_R[1]&&!(__Esterel_Dining_Phil_R[0]))||__Esterel_Dining_Phil_R[0];
E[1] = (__Esterel_Dining_Phil_R[8]&&!(__Esterel_Dining_Phil_R[0]))||(__Esterel_Dining_Phil_R[9]&&!(__Esterel_Dining_Phil_R[0]));
E[2] = __Esterel_Dining_Phil_R[10]&&!(__Esterel_Dining_Phil_R[0]);
E[3] = __Esterel_Dining_Phil_R[11]&&!(__Esterel_Dining_Phil_R[0]);
E[4] = __Esterel_Dining_Phil_R[12]&&!(__Esterel_Dining_Phil_R[0]);
E[5] = __Esterel_Dining_Phil_R[66]&&!(__Esterel_Dining_Phil_R[0]);
E[6] = __Esterel_Dining_Phil_R[67]&&!(__Esterel_Dining_Phil_R[0]);
E[7] = __Esterel_Dining_Phil_R[68]&&!(__Esterel_Dining_Phil_R[0]);
E[8] = __Esterel_Dining_Phil_R[69]&&!(__Esterel_Dining_Phil_R[0]);
E[9] = E[1]||E[2]||E[3]||E[4]||E[5]||E[6]||E[7]||E[8];
E[10] = E[0]&&E[9];
if (E[10]) {
__Esterel_Dining_Phil_A50;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A50\n");
#endif
}
E[0] = E[10]||(E[0]&&!(E[9]));
E[11] = __Esterel_Dining_Phil_R[13]&&!(__Esterel_Dining_Phil_R[0]);
E[12] = (__Esterel_Dining_Phil_R[22]&&!(__Esterel_Dining_Phil_R[0]))||(__Esterel_Dining_Phil_R[23]&&!(__Esterel_Dining_Phil_R[0]));
E[13] = __Esterel_Dining_Phil_R[24]&&!(__Esterel_Dining_Phil_R[0]);
E[14] = __Esterel_Dining_Phil_R[25]&&!(__Esterel_Dining_Phil_R[0]);
E[15] = __Esterel_Dining_Phil_R[26]&&!(__Esterel_Dining_Phil_R[0]);
E[16] = E[2]||E[3]||E[4]||E[11]||E[12]||E[13]||E[14]||E[15];
E[17] = E[0]&&E[16];
if (E[17]) {
__Esterel_Dining_Phil_A51;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A51\n");
#endif
}
E[0] = E[17]||(E[0]&&!(E[16]));
E[18] = __Esterel_Dining_Phil_R[27]&&!(__Esterel_Dining_Phil_R[0]);
E[19] = (__Esterel_Dining_Phil_R[36]&&!(__Esterel_Dining_Phil_R[0]))||(__Esterel_Dining_Phil_R[37]&&!(__Esterel_Dining_Phil_R[0]));
E[20] = __Esterel_Dining_Phil_R[38]&&!(__Esterel_Dining_Phil_R[0]);
E[21] = __Esterel_Dining_Phil_R[39]&&!(__Esterel_Dining_Phil_R[0]);
E[22] = __Esterel_Dining_Phil_R[40]&&!(__Esterel_Dining_Phil_R[0]);
E[23] = E[13]||E[14]||E[15]||E[18]||E[19]||E[20]||E[21]||E[22];
E[24] = E[0]&&E[23];
if (E[24]) {
__Esterel_Dining_Phil_A52;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A52\n");
#endif
}
E[0] = E[24]||(E[0]&&!(E[23]));
E[25] = __Esterel_Dining_Phil_R[41]&&!(__Esterel_Dining_Phil_R[0]);
E[26] = (__Esterel_Dining_Phil_R[50]&&!(__Esterel_Dining_Phil_R[0]))||(__Esterel_Dining_Phil_R[51]&&!(__Esterel_Dining_Phil_R[0]));
E[27] = __Esterel_Dining_Phil_R[52]&&!(__Esterel_Dining_Phil_R[0]);
E[28] = __Esterel_Dining_Phil_R[53]&&!(__Esterel_Dining_Phil_R[0]);
E[29] = __Esterel_Dining_Phil_R[54]&&!(__Esterel_Dining_Phil_R[0]);
E[30] = E[20]||E[21]||E[22]||E[25]||E[26]||E[27]||E[28]||E[29];
E[31] = E[0]&&E[30];
if (E[31]) {
__Esterel_Dining_Phil_A53;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A53\n");
#endif
}
E[0] = E[31]||(E[0]&&!(E[30]));
E[32] = __Esterel_Dining_Phil_R[55]&&!(__Esterel_Dining_Phil_R[0]);
E[33] = (__Esterel_Dining_Phil_R[64]&&!(__Esterel_Dining_Phil_R[0]))||(__Esterel_Dining_Phil_R[65]&&!(__Esterel_Dining_Phil_R[0]));
E[34] = E[27]||E[28]||E[29]||E[32]||E[33]||E[5]||E[6]||E[7];
E[35] = E[0]&&E[34];
if (E[35]) {
__Esterel_Dining_Phil_A54;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A54\n");
#endif
}
E[0] = E[35]||(E[0]&&!(E[34]));
if (E[0]) {
__Esterel_Dining_Phil_A55;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A55\n");
#endif
}
if (E[10]||E[17]||E[24]||E[31]||E[35]||E[0]) {
__Esterel_Dining_Phil_A1;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A1\n");
#endif
}
if (E[9]) {
__Esterel_Dining_Phil_A2;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A2\n");
#endif
}
if (E[16]) {
__Esterel_Dining_Phil_A3;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A3\n");
#endif
}
if (E[23]) {
__Esterel_Dining_Phil_A4;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A4\n");
#endif
}
if (E[30]) {
__Esterel_Dining_Phil_A5;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A5\n");
#endif
}
if (E[34]) {
__Esterel_Dining_Phil_A6;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A6\n");
#endif
}
if (E[1]) {
__Esterel_Dining_Phil_A7;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A7\n");
#endif
}
if (E[12]) {
__Esterel_Dining_Phil_A8;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A8\n");
#endif
}
if (E[19]) {
__Esterel_Dining_Phil_A9;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A9\n");
#endif
}
if (E[26]) {
__Esterel_Dining_Phil_A10;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A10\n");
#endif
}
if (E[33]) {
__Esterel_Dining_Phil_A11;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A11\n");
#endif
}
E[36] = __Esterel_Dining_Phil_R[0]||(__Esterel_Dining_Phil_R[15]&&!(__Esterel_Dining_Phil_R[0]));
E[37] = __Esterel_Dining_Phil_R[2]&&!(__Esterel_Dining_Phil_R[0]);
E[38] = __Esterel_Dining_Phil_R[3]&&!(__Esterel_Dining_Phil_R[0]);
E[39] = __Esterel_Dining_Phil_R[4]&&!(__Esterel_Dining_Phil_R[0]);
E[40] = __Esterel_Dining_Phil_R[5]&&!(__Esterel_Dining_Phil_R[0]);
E[41] = (__Esterel_Dining_Phil_R[6]&&!(__Esterel_Dining_Phil_R[0]))||(__Esterel_Dining_Phil_R[7]&&!(__Esterel_Dining_Phil_R[0]));
E[42] = __Esterel_Dining_Phil_R[14]&&!(__Esterel_Dining_Phil_R[0]);
E[43] = E[36]||E[37]||E[38]||E[39]||E[40]||E[41]||E[11]||E[42];
if (E[43]) {
__Esterel_Dining_Phil_A12;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A12\n");
#endif
}
E[44] = __Esterel_Dining_Phil_R[0]||(__Esterel_Dining_Phil_R[29]&&!(__Esterel_Dining_Phil_R[0]));
E[45] = __Esterel_Dining_Phil_R[16]&&!(__Esterel_Dining_Phil_R[0]);
E[46] = __Esterel_Dining_Phil_R[17]&&!(__Esterel_Dining_Phil_R[0]);
E[47] = __Esterel_Dining_Phil_R[18]&&!(__Esterel_Dining_Phil_R[0]);
E[48] = __Esterel_Dining_Phil_R[19]&&!(__Esterel_Dining_Phil_R[0]);
E[49] = (__Esterel_Dining_Phil_R[20]&&!(__Esterel_Dining_Phil_R[0]))||(__Esterel_Dining_Phil_R[21]&&!(__Esterel_Dining_Phil_R[0]));
E[50] = __Esterel_Dining_Phil_R[28]&&!(__Esterel_Dining_Phil_R[0]);
E[51] = E[44]||E[45]||E[46]||E[47]||E[48]||E[49]||E[18]||E[50];
if (E[51]) {
__Esterel_Dining_Phil_A13;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A13\n");
#endif
}
E[52] = __Esterel_Dining_Phil_R[0]||(__Esterel_Dining_Phil_R[43]&&!(__Esterel_Dining_Phil_R[0]));
E[53] = __Esterel_Dining_Phil_R[30]&&!(__Esterel_Dining_Phil_R[0]);
E[54] = __Esterel_Dining_Phil_R[31]&&!(__Esterel_Dining_Phil_R[0]);
E[55] = __Esterel_Dining_Phil_R[32]&&!(__Esterel_Dining_Phil_R[0]);
E[56] = __Esterel_Dining_Phil_R[33]&&!(__Esterel_Dining_Phil_R[0]);
E[57] = (__Esterel_Dining_Phil_R[34]&&!(__Esterel_Dining_Phil_R[0]))||(__Esterel_Dining_Phil_R[35]&&!(__Esterel_Dining_Phil_R[0]));
E[58] = __Esterel_Dining_Phil_R[42]&&!(__Esterel_Dining_Phil_R[0]);
E[59] = E[52]||E[53]||E[54]||E[55]||E[56]||E[57]||E[25]||E[58];
if (E[59]) {
__Esterel_Dining_Phil_A14;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A14\n");
#endif
}
E[60] = __Esterel_Dining_Phil_R[0]||(__Esterel_Dining_Phil_R[57]&&!(__Esterel_Dining_Phil_R[0]));
E[61] = __Esterel_Dining_Phil_R[44]&&!(__Esterel_Dining_Phil_R[0]);
E[62] = __Esterel_Dining_Phil_R[45]&&!(__Esterel_Dining_Phil_R[0]);
E[63] = __Esterel_Dining_Phil_R[46]&&!(__Esterel_Dining_Phil_R[0]);
E[64] = __Esterel_Dining_Phil_R[47]&&!(__Esterel_Dining_Phil_R[0]);
E[65] = (__Esterel_Dining_Phil_R[48]&&!(__Esterel_Dining_Phil_R[0]))||(__Esterel_Dining_Phil_R[49]&&!(__Esterel_Dining_Phil_R[0]));
E[66] = __Esterel_Dining_Phil_R[56]&&!(__Esterel_Dining_Phil_R[0]);
E[67] = E[60]||E[61]||E[62]||E[63]||E[64]||E[65]||E[32]||E[66];
if (E[67]) {
__Esterel_Dining_Phil_A15;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A15\n");
#endif
}
E[68] = __Esterel_Dining_Phil_R[0]||(__Esterel_Dining_Phil_R[71]&&!(__Esterel_Dining_Phil_R[0]));
E[69] = __Esterel_Dining_Phil_R[58]&&!(__Esterel_Dining_Phil_R[0]);
E[70] = __Esterel_Dining_Phil_R[59]&&!(__Esterel_Dining_Phil_R[0]);
E[71] = __Esterel_Dining_Phil_R[60]&&!(__Esterel_Dining_Phil_R[0]);
E[72] = __Esterel_Dining_Phil_R[61]&&!(__Esterel_Dining_Phil_R[0]);
E[73] = (__Esterel_Dining_Phil_R[62]&&!(__Esterel_Dining_Phil_R[0]))||(__Esterel_Dining_Phil_R[63]&&!(__Esterel_Dining_Phil_R[0]));
E[74] = __Esterel_Dining_Phil_R[70]&&!(__Esterel_Dining_Phil_R[0]);
E[75] = E[68]||E[69]||E[70]||E[71]||E[72]||E[73]||E[8]||E[74];
if (E[75]) {
__Esterel_Dining_Phil_A16;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A16\n");
#endif
}
E[76] = E[2]||E[3]||E[4];
if (E[76]) {
__Esterel_Dining_Phil_A17;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A17\n");
#endif
}
E[77] = E[13]||E[14]||E[15];
if (E[77]) {
__Esterel_Dining_Phil_A18;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A18\n");
#endif
}
E[78] = E[20]||E[21]||E[22];
if (E[78]) {
__Esterel_Dining_Phil_A19;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A19\n");
#endif
}
E[79] = E[27]||E[28]||E[29];
if (E[79]) {
__Esterel_Dining_Phil_A20;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A20\n");
#endif
}
E[80] = E[5]||E[6]||E[7];
if (E[80]) {
__Esterel_Dining_Phil_A21;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A21\n");
#endif
}
E[81] = E[41]&&!(E[9]);
E[82] = E[81]||E[1]||E[2]||E[3]||E[4]||E[11];
if (E[82]) {
__Esterel_Dining_Phil_A22;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A22\n");
#endif
}
E[83] = E[49]&&!(E[16]);
E[84] = E[83]||E[12]||E[13]||E[14]||E[15]||E[18];
if (E[84]) {
__Esterel_Dining_Phil_A23;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A23\n");
#endif
}
E[85] = E[57]&&!(E[23]);
E[86] = E[85]||E[19]||E[20]||E[21]||E[22]||E[25];
if (E[86]) {
__Esterel_Dining_Phil_A24;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A24\n");
#endif
}
E[87] = E[65]&&!(E[30]);
E[88] = E[87]||E[26]||E[27]||E[28]||E[29]||E[32];
if (E[88]) {
__Esterel_Dining_Phil_A25;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A25\n");
#endif
}
E[89] = E[73]&&!(E[34]);
E[90] = E[89]||E[33]||E[5]||E[6]||E[7]||E[8];
if (E[90]) {
__Esterel_Dining_Phil_A26;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A26\n");
#endif
}
E[91] = (__Esterel_Dining_Phil_R[72]&&!(__Esterel_Dining_Phil_R[0]))||__Esterel_Dining_Phil_R[0];
E[92] = E[82]&&E[84]&&E[86]&&E[88]&&E[90];
E[93] = E[91]&&E[92];
E[92] = E[91]&&!(E[92]);
E[91] = E[92]&&E[82];
E[94] = E[93]||E[91];
if (E[94]) {
__Esterel_Dining_Phil_A27;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A27\n");
#endif
}
E[92] = E[91]||(E[92]&&!(E[82]));
E[91] = E[92]&&E[84];
E[95] = E[93]||E[91];
if (E[95]) {
__Esterel_Dining_Phil_A28;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A28\n");
#endif
}
E[92] = E[91]||(E[92]&&!(E[84]));
E[91] = E[92]&&E[86];
E[96] = E[93]||E[91];
if (E[96]) {
__Esterel_Dining_Phil_A29;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A29\n");
#endif
}
E[92] = E[91]||(E[92]&&!(E[86]));
E[91] = E[92]&&E[88];
E[97] = E[93]||E[91];
if (E[97]) {
__Esterel_Dining_Phil_A30;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A30\n");
#endif
}
E[92] = E[91]||(E[92]&&!(E[88]));
E[91] = E[92]&&E[90];
if (E[91]) {
__Esterel_Dining_Phil_A31;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A31\n");
#endif
}
E[98] = (__Esterel_Dining_Phil_R[73]&&!(__Esterel_Dining_Phil_R[0]))||__Esterel_Dining_Phil_R[0];
E[99] = E[1]&&E[12]&&E[19]&&E[26]&&E[33];
E[100] = E[98]&&E[99];
if (E[100]) {
__Esterel_Dining_Phil_A32;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A32\n");
#endif
}
E[101] = (__Esterel_Dining_Phil_R[74]&&!(__Esterel_Dining_Phil_R[0]))||__Esterel_Dining_Phil_R[0];
E[102] = (E[76]&&E[80])||(E[1]&&E[80]);
E[103] = E[101]&&E[102];
if (E[103]) {
__Esterel_Dining_Phil_A33;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A33\n");
#endif
}
E[102] = E[103]||(E[101]&&!(E[102]));
E[101] = (E[77]&&E[76])||(E[12]&&E[76]);
E[104] = E[102]&&E[101];
if (E[104]) {
__Esterel_Dining_Phil_A34;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A34\n");
#endif
}
E[101] = E[104]||(E[102]&&!(E[101]));
E[102] = (E[78]&&E[77])||(E[19]&&E[77]);
E[105] = E[101]&&E[102];
if (E[105]) {
__Esterel_Dining_Phil_A35;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A35\n");
#endif
}
E[102] = E[105]||(E[101]&&!(E[102]));
E[101] = (E[79]&&E[78])||(E[26]&&E[78]);
E[106] = E[102]&&E[101];
if (E[106]) {
__Esterel_Dining_Phil_A36;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A36\n");
#endif
}
E[101] = E[106]||(E[102]&&!(E[101]));
E[102] = (E[80]&&E[79])||(E[33]&&E[79]);
E[107] = E[101]&&E[102];
if (E[107]) {
__Esterel_Dining_Phil_A37;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A37\n");
#endif
}
E[108] = (__Esterel_Dining_Phil_R[75]&&!(__Esterel_Dining_Phil_R[0]))||__Esterel_Dining_Phil_R[0];
E[109] = (E[76]&&E[1])||(E[1]&&E[43])||(E[76]&&E[43]);
E[110] = E[108]&&!(E[109]);
if (E[110]) {
__Esterel_Dining_Phil_A38;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A38\n");
#endif
}
E[109] = E[110]||(E[108]&&E[109]);
E[108] = (E[77]&&E[12])||(E[12]&&E[51])||(E[77]&&E[51]);
E[111] = E[109]&&!(E[108]);
if (E[111]) {
__Esterel_Dining_Phil_A39;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A39\n");
#endif
}
E[108] = E[111]||(E[109]&&E[108]);
E[109] = (E[78]&&E[19])||(E[19]&&E[59])||(E[78]&&E[59]);
E[112] = E[108]&&!(E[109]);
if (E[112]) {
__Esterel_Dining_Phil_A40;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A40\n");
#endif
}
E[109] = E[112]||(E[108]&&E[109]);
E[108] = (E[79]&&E[26])||(E[26]&&E[67])||(E[79]&&E[67]);
E[113] = E[109]&&!(E[108]);
if (E[113]) {
__Esterel_Dining_Phil_A41;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A41\n");
#endif
}
E[108] = E[113]||(E[109]&&E[108]);
E[109] = (E[80]&&E[33])||(E[33]&&E[75])||(E[80]&&E[75]);
E[114] = E[108]&&!(E[109]);
if (E[114]) {
__Esterel_Dining_Phil_A42;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A42\n");
#endif
}
E[115] = __Esterel_Dining_Phil_R[77]&&!(__Esterel_Dining_Phil_R[0]);
E[116] = E[115]&&(
#ifdef TRACE_ACTION
fprintf(stderr, "test 61\n"),
#endif
__Esterel_Dining_Phil_A61);
if (E[116]) {
__Esterel_Dining_Phil_A43;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A43\n");
#endif
}
E[117] = __Esterel_Dining_Phil_R[80]&&!(__Esterel_Dining_Phil_R[0]);
E[118] = E[117]&&(
#ifdef TRACE_ACTION
fprintf(stderr, "test 62\n"),
#endif
__Esterel_Dining_Phil_A62);
if (E[118]) {
__Esterel_Dining_Phil_A44;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A44\n");
#endif
}
E[119] = __Esterel_Dining_Phil_R[83]&&!(__Esterel_Dining_Phil_R[0]);
E[120] = E[119]&&(
#ifdef TRACE_ACTION
fprintf(stderr, "test 63\n"),
#endif
__Esterel_Dining_Phil_A63);
if (E[120]) {
__Esterel_Dining_Phil_A45;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A45\n");
#endif
}
E[121] = __Esterel_Dining_Phil_R[86]&&!(__Esterel_Dining_Phil_R[0]);
E[122] = E[121]&&(
#ifdef TRACE_ACTION
fprintf(stderr, "test 64\n"),
#endif
__Esterel_Dining_Phil_A64);
if (E[122]) {
__Esterel_Dining_Phil_A46;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A46\n");
#endif
}
E[123] = __Esterel_Dining_Phil_R[89]&&!(__Esterel_Dining_Phil_R[0]);
E[124] = E[123]&&(
#ifdef TRACE_ACTION
fprintf(stderr, "test 65\n"),
#endif
__Esterel_Dining_Phil_A65);
if (E[124]) {
__Esterel_Dining_Phil_A47;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A47\n");
#endif
}
E[125] = E[81]&&E[94];
E[126] = E[1]&&!(E[16]);
E[127] = E[83]&&E[95];
E[128] = E[12]&&!(E[23]);
E[129] = E[85]&&E[96];
E[130] = E[19]&&!(E[30]);
E[131] = E[87]&&E[97];
E[132] = E[26]&&!(E[34]);
E[133] = E[89]&&E[91];
E[134] = E[33]&&!(E[9]);
E[135] = !(_true);
E[136] = E[1]&&E[16];
E[81] = (E[41]&&E[9])||(E[81]&&!(E[94]));
E[41] = E[12]&&E[23];
E[83] = (E[49]&&E[16])||(E[83]&&!(E[95]));
E[49] = E[19]&&E[30];
E[85] = (E[57]&&E[23])||(E[85]&&!(E[96]));
E[57] = E[26]&&E[34];
E[87] = (E[65]&&E[30])||(E[87]&&!(E[97]));
E[65] = E[33]&&E[9];
E[89] = (E[73]&&E[34])||(E[89]&&!(E[91]));
E[92] = E[93]||E[91]||(E[92]&&!(E[90]));
E[99] = E[100]||(E[98]&&!(E[99]));
E[102] = E[107]||(E[101]&&!(E[102]));
E[109] = E[114]||(E[108]&&E[109]);
E[108] = __Esterel_Dining_Phil_R[78]&&!(__Esterel_Dining_Phil_R[0]);
E[101] = __Esterel_Dining_Phil_R[81]&&!(__Esterel_Dining_Phil_R[0]);
E[98] = __Esterel_Dining_Phil_R[84]&&!(__Esterel_Dining_Phil_R[0]);
E[93] = __Esterel_Dining_Phil_R[87]&&!(__Esterel_Dining_Phil_R[0]);
E[73] = __Esterel_Dining_Phil_R[90]&&!(__Esterel_Dining_Phil_R[0]);
E[137] = __Esterel_Dining_Phil_R[78]||__Esterel_Dining_Phil_R[77]||__Esterel_Dining_Phil_R[76];
E[138] = __Esterel_Dining_Phil_R[81]||__Esterel_Dining_Phil_R[80]||__Esterel_Dining_Phil_R[79];
E[139] = __Esterel_Dining_Phil_R[84]||__Esterel_Dining_Phil_R[83]||__Esterel_Dining_Phil_R[82];
E[140] = __Esterel_Dining_Phil_R[87]||__Esterel_Dining_Phil_R[86]||__Esterel_Dining_Phil_R[85];
E[141] = __Esterel_Dining_Phil_R[90]||__Esterel_Dining_Phil_R[89]||__Esterel_Dining_Phil_R[88];
E[142] = E[137]||E[138]||E[139]||E[140]||E[141];
E[137] = (E[142]&&!(E[137]))||E[108];
E[138] = (E[142]&&!(E[138]))||E[101];
E[139] = (E[142]&&!(E[139]))||E[98];
E[140] = (E[142]&&!(E[140]))||E[93];
E[141] = (E[142]&&!(E[141]))||E[73];
E[73] = ((E[108]||E[101]||E[98]||E[93]||E[73])&&E[137]&&E[138]&&E[139]&&E[140]&&E[141])||__Esterel_Dining_Phil_R[0];
E[93] = E[73]&&E[1];
if (E[93]) {
__Esterel_Dining_Phil_A56;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A56\n");
#endif
}
E[98] = E[93]&&E[76];
E[101] = E[93]&&!(E[76]);
E[108] = E[73]&&!(E[1]);
E[143] = E[73]&&E[12];
if (E[143]) {
__Esterel_Dining_Phil_A57;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A57\n");
#endif
}
E[144] = E[143]&&E[77];
E[145] = E[143]&&!(E[77]);
E[146] = E[73]&&!(E[12]);
E[147] = E[73]&&E[19];
if (E[147]) {
__Esterel_Dining_Phil_A58;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A58\n");
#endif
}
E[148] = E[147]&&E[78];
E[149] = E[147]&&!(E[78]);
E[150] = E[73]&&!(E[19]);
E[151] = E[73]&&E[26];
if (E[151]) {
__Esterel_Dining_Phil_A59;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A59\n");
#endif
}
E[152] = E[151]&&E[79];
E[153] = E[151]&&!(E[79]);
E[154] = E[73]&&!(E[26]);
E[155] = E[73]&&E[33];
if (E[155]) {
__Esterel_Dining_Phil_A60;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A60\n");
#endif
}
E[156] = E[155]&&E[80];
E[157] = E[155]&&!(E[80]);
E[73] = E[73]&&!(E[33]);
E[158] = (E[98]||E[101]||E[108]||E[144]||E[145]||E[146]||E[148]||E[149]||E[150]||E[152]||E[153]||E[154]||E[156]||E[157]||E[73])&&(E[98]||E[101]||E[108])&&(E[144]||E[145]||E[146])&&(E[148]||E[149]||E[150])&&(E[152]||E[153]||E[154])&&(E[156]||E[157]||E[73]);
E[115] = __Esterel_Dining_Phil_R[77]&&E[115]&&!(E[116]);
E[159] = __Esterel_Dining_Phil_R[76]&&!(__Esterel_Dining_Phil_R[0]);
E[160] = E[159]&&E[1];
if (E[160]) {
__Esterel_Dining_Phil_A56;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A56\n");
#endif
}
E[161] = E[116]||(E[115]&&E[76])||(E[160]&&E[76]);
E[115] = (__Esterel_Dining_Phil_R[77]&&E[115]&&!(E[76]))||(E[160]&&!(E[76]));
E[159] = __Esterel_Dining_Phil_R[76]&&E[159]&&!(E[1]);
E[117] = __Esterel_Dining_Phil_R[80]&&E[117]&&!(E[118]);
E[162] = __Esterel_Dining_Phil_R[79]&&!(__Esterel_Dining_Phil_R[0]);
E[163] = E[162]&&E[12];
if (E[163]) {
__Esterel_Dining_Phil_A57;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A57\n");
#endif
}
E[164] = E[118]||(E[117]&&E[77])||(E[163]&&E[77]);
E[117] = (__Esterel_Dining_Phil_R[80]&&E[117]&&!(E[77]))||(E[163]&&!(E[77]));
E[162] = __Esterel_Dining_Phil_R[79]&&E[162]&&!(E[12]);
E[119] = __Esterel_Dining_Phil_R[83]&&E[119]&&!(E[120]);
E[165] = __Esterel_Dining_Phil_R[82]&&!(__Esterel_Dining_Phil_R[0]);
E[166] = E[165]&&E[19];
if (E[166]) {
__Esterel_Dining_Phil_A58;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A58\n");
#endif
}
E[167] = E[120]||(E[119]&&E[78])||(E[166]&&E[78]);
E[119] = (__Esterel_Dining_Phil_R[83]&&E[119]&&!(E[78]))||(E[166]&&!(E[78]));
E[165] = __Esterel_Dining_Phil_R[82]&&E[165]&&!(E[19]);
E[121] = __Esterel_Dining_Phil_R[86]&&E[121]&&!(E[122]);
E[168] = __Esterel_Dining_Phil_R[85]&&!(__Esterel_Dining_Phil_R[0]);
E[169] = E[168]&&E[26];
if (E[169]) {
__Esterel_Dining_Phil_A59;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A59\n");
#endif
}
E[170] = E[122]||(E[121]&&E[79])||(E[169]&&E[79]);
E[121] = (__Esterel_Dining_Phil_R[86]&&E[121]&&!(E[79]))||(E[169]&&!(E[79]));
E[168] = __Esterel_Dining_Phil_R[85]&&E[168]&&!(E[26]);
E[123] = __Esterel_Dining_Phil_R[89]&&E[123]&&!(E[124]);
E[171] = __Esterel_Dining_Phil_R[88]&&!(__Esterel_Dining_Phil_R[0]);
E[172] = E[171]&&E[33];
if (E[172]) {
__Esterel_Dining_Phil_A60;
#ifdef TRACE_ACTION
fprintf(stderr, "__Esterel_Dining_Phil_A60\n");
#endif
}
E[173] = E[124]||(E[123]&&E[80])||(E[172]&&E[80]);
E[123] = (__Esterel_Dining_Phil_R[89]&&E[123]&&!(E[80]))||(E[172]&&!(E[80]));
E[171] = __Esterel_Dining_Phil_R[88]&&E[171]&&!(E[33]);
E[141] = (E[161]||E[115]||E[159]||E[164]||E[117]||E[162]||E[167]||E[119]||E[165]||E[170]||E[121]||E[168]||E[173]||E[123]||E[171])&&(E[137]||E[161]||E[115]||E[159])&&(E[138]||E[164]||E[117]||E[162])&&(E[139]||E[167]||E[119]||E[165])&&(E[140]||E[170]||E[121]||E[168])&&(E[141]||E[173]||E[123]||E[171]);
E[140] = __Esterel_Dining_Phil_R[73]||__Esterel_Dining_Phil_R[74]||__Esterel_Dining_Phil_R[75]||E[142];
E[141] = (E[99]||E[102]||E[109]||E[158]||E[141])&&((E[140]&&!(__Esterel_Dining_Phil_R[73]))||E[99])&&((E[140]&&!(__Esterel_Dining_Phil_R[74]))||E[102])&&((E[140]&&!(__Esterel_Dining_Phil_R[75]))||E[109])&&((E[140]&&!(E[142]))||E[158]||E[141]);
E[158] = __Esterel_Dining_Phil_R[2]||__Esterel_Dining_Phil_R[3]||__Esterel_Dining_Phil_R[4]||__Esterel_Dining_Phil_R[5]||__Esterel_Dining_Phil_R[6]||__Esterel_Dining_Phil_R[8]||__Esterel_Dining_Phil_R[10]||__Esterel_Dining_Phil_R[11]||__Esterel_Dining_Phil_R[12]||__Esterel_Dining_Phil_R[13]||__Esterel_Dining_Phil_R[14]||__Esterel_Dining_Phil_R[15]||__Esterel_Dining_Phil_R[9]||__Esterel_Dining_Phil_R[7];
E[142] = __Esterel_Dining_Phil_R[16]||__Esterel_Dining_Phil_R[17]||__Esterel_Dining_Phil_R[18]||__Esterel_Dining_Phil_R[19]||__Esterel_Dining_Phil_R[20]||__Esterel_Dining_Phil_R[22]||__Esterel_Dining_Phil_R[24]||__Esterel_Dining_Phil_R[25]||__Esterel_Dining_Phil_R[26]||__Esterel_Dining_Phil_R[27]||__Esterel_Dining_Phil_R[28]||__Esterel_Dining_Phil_R[29]||__Esterel_Dining_Phil_R[23]||__Esterel_Dining_Phil_R[21];
E[139] = __Esterel_Dining_Phil_R[30]||__Esterel_Dining_Phil_R[31]||__Esterel_Dining_Phil_R[32]||__Esterel_Dining_Phil_R[33]||__Esterel_Dining_Phil_R[34]||__Esterel_Dining_Phil_R[36]||__Esterel_Dining_Phil_R[38]||__Esterel_Dining_Phil_R[39]||__Esterel_Dining_Phil_R[40]||__Esterel_Dining_Phil_R[41]||__Esterel_Dining_Phil_R[42]||__Esterel_Dining_Phil_R[43]||__Esterel_Dining_Phil_R[37]||__Esterel_Dining_Phil_R[35];
E[138] = __Esterel_Dining_Phil_R[44]||__Esterel_Dining_Phil_R[45]||__Esterel_Dining_Phil_R[46]||__Esterel_Dining_Phil_R[47]||__Esterel_Dining_Phil_R[48]||__Esterel_Dining_Phil_R[50]||__Esterel_Dining_Phil_R[52]||__Esterel_Dining_Phil_R[53]||__Esterel_Dining_Phil_R[54]||__Esterel_Dining_Phil_R[55]||__Esterel_Dining_Phil_R[56]||__Esterel_Dining_Phil_R[57]||__Esterel_Dining_Phil_R[51]||__Esterel_Dining_Phil_R[49];
E[137] = __Esterel_Dining_Phil_R[58]||__Esterel_Dining_Phil_R[59]||__Esterel_Dining_Phil_R[60]||__Esterel_Dining_Phil_R[61]||__Esterel_Dining_Phil_R[62]||__Esterel_Dining_Phil_R[64]||__Esterel_Dining_Phil_R[66]||__Esterel_Dining_Phil_R[67]||__Esterel_Dining_Phil_R[68]||__Esterel_Dining_Phil_R[69]||__Esterel_Dining_Phil_R[70]||__Esterel_Dining_Phil_R[71]||__Esterel_Dining_Phil_R[65]||__Esterel_Dining_Phil_R[63];
E[174] = E[158]||E[142]||E[139]||E[138]||E[137]||__Esterel_Dining_Phil_R[72]||__Esterel_Dining_Phil_R[1]||E[140];
E[141] = (E[36]||E[37]||E[38]||E[39]||E[40]||E[125]||E[126]||E[2]||E[3]||E[4]||E[11]||E[42]||E[136]||E[81]||E[44]||E[45]||E[46]||E[47]||E[48]||E[127]||E[128]||E[13]||E[14]||E[15]||E[18]||E[50]||E[41]||E[83]||E[52]||E[53]||E[54]||E[55]||E[56]||E[129]||E[130]||E[20]||E[21]||E[22]||E[25]||E[58]||E[49]||E[85]||E[60]||E[61]||E[62]||E[63]||E[64]||E[131]||E[132]||E[27]||E[28]||E[29]||E[32]||E[66]||E[57]||E[87]||E[68]||E[69]||E[70]||E[71]||E[72]||E[133]||E[134]||E[5]||E[6]||E[7]||E[8]||E[74]||E[65]||E[89]||E[92]||E[0]||E[141])&&((E[174]&&!(E[158]))||E[36]||E[37]||E[38]||E[39]||E[40]||E[125]||E[126]||E[2]||E[3]||E[4]||E[11]||E[42]||E[136]||E[81])&&((E[174]&&!(E[142]))||E[44]||E[45]||E[46]||E[47]||E[48]||E[127]||E[128]||E[13]||E[14]||E[15]||E[18]||E[50]||E[41]||E[83])&&((E[174]&&!(E[139]))||E[52]||E[53]||E[54]||E[55]||E[56]||E[129]||E[130]||E[20]||E[21]||E[22]||E[25]||E[58]||E[49]||E[85])&&((E[174]&&!(E[138]))||E[60]||E[61]||E[62]||E[63]||E[64]||E[131]||E[132]||E[27]||E[28]||E[29]||E[32]||E[66]||E[57]||E[87])&&((E[174]&&!(E[137]))||E[68]||E[69]||E[70]||E[71]||E[72]||E[133]||E[134]||E[5]||E[6]||E[7]||E[8]||E[74]||E[65]||E[89])&&((E[174]&&!(__Esterel_Dining_Phil_R[72]))||E[92])&&((E[174]&&!(__Esterel_Dining_Phil_R[1]))||E[0])&&((E[174]&&!(E[140]))||E[141]);
__Esterel_Dining_Phil_R[76] = E[108]||E[159];
__Esterel_Dining_Phil_R[77] = E[101]||E[115];
__Esterel_Dining_Phil_R[78] = E[98]||E[161];
__Esterel_Dining_Phil_R[79] = E[146]||E[162];
__Esterel_Dining_Phil_R[80] = E[145]||E[117];
__Esterel_Dining_Phil_R[81] = E[144]||E[164];
__Esterel_Dining_Phil_R[82] = E[150]||E[165];
__Esterel_Dining_Phil_R[83] = E[149]||E[119];
__Esterel_Dining_Phil_R[84] = E[148]||E[167];
__Esterel_Dining_Phil_R[85] = E[154]||E[168];
__Esterel_Dining_Phil_R[86] = E[153]||E[121];
__Esterel_Dining_Phil_R[87] = E[152]||E[170];
__Esterel_Dining_Phil_R[88] = E[73]||E[171];
__Esterel_Dining_Phil_R[89] = E[157]||E[123];
__Esterel_Dining_Phil_R[90] = E[156]||E[173];
__Esterel_Dining_Phil_R[0] = !(_true);
__Esterel_Dining_Phil_R[1] = E[0];
__Esterel_Dining_Phil_R[2] = E[36];
__Esterel_Dining_Phil_R[3] = E[37];
__Esterel_Dining_Phil_R[4] = E[38];
__Esterel_Dining_Phil_R[5] = E[39];
__Esterel_Dining_Phil_R[6] = E[40];
__Esterel_Dining_Phil_R[7] = E[81];
__Esterel_Dining_Phil_R[8] = E[125];
__Esterel_Dining_Phil_R[9] = E[136];
__Esterel_Dining_Phil_R[10] = E[126];
__Esterel_Dining_Phil_R[11] = E[2];
__Esterel_Dining_Phil_R[12] = E[3];
__Esterel_Dining_Phil_R[13] = E[4];
__Esterel_Dining_Phil_R[14] = E[11];
__Esterel_Dining_Phil_R[15] = E[42];
__Esterel_Dining_Phil_R[16] = E[44];
__Esterel_Dining_Phil_R[17] = E[45];
__Esterel_Dining_Phil_R[18] = E[46];
__Esterel_Dining_Phil_R[19] = E[47];
__Esterel_Dining_Phil_R[20] = E[48];
__Esterel_Dining_Phil_R[21] = E[83];
__Esterel_Dining_Phil_R[22] = E[127];
__Esterel_Dining_Phil_R[23] = E[41];
__Esterel_Dining_Phil_R[24] = E[128];
__Esterel_Dining_Phil_R[25] = E[13];
__Esterel_Dining_Phil_R[26] = E[14];
__Esterel_Dining_Phil_R[27] = E[15];
__Esterel_Dining_Phil_R[28] = E[18];
__Esterel_Dining_Phil_R[29] = E[50];
__Esterel_Dining_Phil_R[30] = E[52];
__Esterel_Dining_Phil_R[31] = E[53];
__Esterel_Dining_Phil_R[32] = E[54];
__Esterel_Dining_Phil_R[33] = E[55];
__Esterel_Dining_Phil_R[34] = E[56];
__Esterel_Dining_Phil_R[35] = E[85];
__Esterel_Dining_Phil_R[36] = E[129];
__Esterel_Dining_Phil_R[37] = E[49];
__Esterel_Dining_Phil_R[38] = E[130];
__Esterel_Dining_Phil_R[39] = E[20];
__Esterel_Dining_Phil_R[40] = E[21];
__Esterel_Dining_Phil_R[41] = E[22];
__Esterel_Dining_Phil_R[42] = E[25];
__Esterel_Dining_Phil_R[43] = E[58];
__Esterel_Dining_Phil_R[44] = E[60];
__Esterel_Dining_Phil_R[45] = E[61];
__Esterel_Dining_Phil_R[46] = E[62];
__Esterel_Dining_Phil_R[47] = E[63];
__Esterel_Dining_Phil_R[48] = E[64];
__Esterel_Dining_Phil_R[49] = E[87];
__Esterel_Dining_Phil_R[50] = E[131];
__Esterel_Dining_Phil_R[51] = E[57];
__Esterel_Dining_Phil_R[52] = E[132];
__Esterel_Dining_Phil_R[53] = E[27];
__Esterel_Dining_Phil_R[54] = E[28];
__Esterel_Dining_Phil_R[55] = E[29];
__Esterel_Dining_Phil_R[56] = E[32];
__Esterel_Dining_Phil_R[57] = E[66];
__Esterel_Dining_Phil_R[58] = E[68];
__Esterel_Dining_Phil_R[59] = E[69];
__Esterel_Dining_Phil_R[60] = E[70];
__Esterel_Dining_Phil_R[61] = E[71];
__Esterel_Dining_Phil_R[62] = E[72];
__Esterel_Dining_Phil_R[63] = E[89];
__Esterel_Dining_Phil_R[64] = E[133];
__Esterel_Dining_Phil_R[65] = E[65];
__Esterel_Dining_Phil_R[66] = E[134];
__Esterel_Dining_Phil_R[67] = E[5];
__Esterel_Dining_Phil_R[68] = E[6];
__Esterel_Dining_Phil_R[69] = E[7];
__Esterel_Dining_Phil_R[70] = E[8];
__Esterel_Dining_Phil_R[71] = E[74];
__Esterel_Dining_Phil_R[72] = E[92];
__Esterel_Dining_Phil_R[73] = E[99];
__Esterel_Dining_Phil_R[74] = E[102];
__Esterel_Dining_Phil_R[75] = E[109];
__Esterel_Dining_Phil__reset_input();
return E[141];
}

/* AUTOMATON RESET */

int Esterel_Dining_Phil_reset () {
__Esterel_Dining_Phil_R[0] = _true;
__Esterel_Dining_Phil_R[1] = _false;
__Esterel_Dining_Phil_R[2] = _false;
__Esterel_Dining_Phil_R[3] = _false;
__Esterel_Dining_Phil_R[4] = _false;
__Esterel_Dining_Phil_R[5] = _false;
__Esterel_Dining_Phil_R[6] = _false;
__Esterel_Dining_Phil_R[7] = _false;
__Esterel_Dining_Phil_R[8] = _false;
__Esterel_Dining_Phil_R[9] = _false;
__Esterel_Dining_Phil_R[10] = _false;
__Esterel_Dining_Phil_R[11] = _false;
__Esterel_Dining_Phil_R[12] = _false;
__Esterel_Dining_Phil_R[13] = _false;
__Esterel_Dining_Phil_R[14] = _false;
__Esterel_Dining_Phil_R[15] = _false;
__Esterel_Dining_Phil_R[16] = _false;
__Esterel_Dining_Phil_R[17] = _false;
__Esterel_Dining_Phil_R[18] = _false;
__Esterel_Dining_Phil_R[19] = _false;
__Esterel_Dining_Phil_R[20] = _false;
__Esterel_Dining_Phil_R[21] = _false;
__Esterel_Dining_Phil_R[22] = _false;
__Esterel_Dining_Phil_R[23] = _false;
__Esterel_Dining_Phil_R[24] = _false;
__Esterel_Dining_Phil_R[25] = _false;
__Esterel_Dining_Phil_R[26] = _false;
__Esterel_Dining_Phil_R[27] = _false;
__Esterel_Dining_Phil_R[28] = _false;
__Esterel_Dining_Phil_R[29] = _false;
__Esterel_Dining_Phil_R[30] = _false;
__Esterel_Dining_Phil_R[31] = _false;
__Esterel_Dining_Phil_R[32] = _false;
__Esterel_Dining_Phil_R[33] = _false;
__Esterel_Dining_Phil_R[34] = _false;
__Esterel_Dining_Phil_R[35] = _false;
__Esterel_Dining_Phil_R[36] = _false;
__Esterel_Dining_Phil_R[37] = _false;
__Esterel_Dining_Phil_R[38] = _false;
__Esterel_Dining_Phil_R[39] = _false;
__Esterel_Dining_Phil_R[40] = _false;
__Esterel_Dining_Phil_R[41] = _false;
__Esterel_Dining_Phil_R[42] = _false;
__Esterel_Dining_Phil_R[43] = _false;
__Esterel_Dining_Phil_R[44] = _false;
__Esterel_Dining_Phil_R[45] = _false;
__Esterel_Dining_Phil_R[46] = _false;
__Esterel_Dining_Phil_R[47] = _false;
__Esterel_Dining_Phil_R[48] = _false;
__Esterel_Dining_Phil_R[49] = _false;
__Esterel_Dining_Phil_R[50] = _false;
__Esterel_Dining_Phil_R[51] = _false;
__Esterel_Dining_Phil_R[52] = _false;
__Esterel_Dining_Phil_R[53] = _false;
__Esterel_Dining_Phil_R[54] = _false;
__Esterel_Dining_Phil_R[55] = _false;
__Esterel_Dining_Phil_R[56] = _false;
__Esterel_Dining_Phil_R[57] = _false;
__Esterel_Dining_Phil_R[58] = _false;
__Esterel_Dining_Phil_R[59] = _false;
__Esterel_Dining_Phil_R[60] = _false;
__Esterel_Dining_Phil_R[61] = _false;
__Esterel_Dining_Phil_R[62] = _false;
__Esterel_Dining_Phil_R[63] = _false;
__Esterel_Dining_Phil_R[64] = _false;
__Esterel_Dining_Phil_R[65] = _false;
__Esterel_Dining_Phil_R[66] = _false;
__Esterel_Dining_Phil_R[67] = _false;
__Esterel_Dining_Phil_R[68] = _false;
__Esterel_Dining_Phil_R[69] = _false;
__Esterel_Dining_Phil_R[70] = _false;
__Esterel_Dining_Phil_R[71] = _false;
__Esterel_Dining_Phil_R[72] = _false;
__Esterel_Dining_Phil_R[73] = _false;
__Esterel_Dining_Phil_R[74] = _false;
__Esterel_Dining_Phil_R[75] = _false;
__Esterel_Dining_Phil_R[76] = _false;
__Esterel_Dining_Phil_R[77] = _false;
__Esterel_Dining_Phil_R[78] = _false;
__Esterel_Dining_Phil_R[79] = _false;
__Esterel_Dining_Phil_R[80] = _false;
__Esterel_Dining_Phil_R[81] = _false;
__Esterel_Dining_Phil_R[82] = _false;
__Esterel_Dining_Phil_R[83] = _false;
__Esterel_Dining_Phil_R[84] = _false;
__Esterel_Dining_Phil_R[85] = _false;
__Esterel_Dining_Phil_R[86] = _false;
__Esterel_Dining_Phil_R[87] = _false;
__Esterel_Dining_Phil_R[88] = _false;
__Esterel_Dining_Phil_R[89] = _false;
__Esterel_Dining_Phil_R[90] = _false;
__Esterel_Dining_Phil__reset_input();
return 0;
}

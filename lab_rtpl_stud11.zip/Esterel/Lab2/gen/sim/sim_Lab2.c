/* sscc : C CODE OF SORTED EQUATIONS Lab2 - SIMULATION MODE */

/* AUXILIARY DECLARATIONS */

#ifndef STRLEN
#define STRLEN 81
#endif
#define _COND(A,B,C) ((A)?(B):(C))
#ifdef TRACE_ACTION
#include <stdio.h>
#endif
#ifndef NULL
#define NULL ((char*)0)
#endif

#ifndef __EXEC_STATUS_H_LOADED
#define __EXEC_STATUS_H_LOADED

typedef struct {
unsigned int start:1;
unsigned int kill:1;
unsigned int active:1;
unsigned int suspended:1;
unsigned int prev_active:1;
unsigned int prev_suspended:1;
unsigned int exec_index;
unsigned int task_exec_index;
void (*pStart)();
void (*pRet)();
} __ExecStatus;

#endif
#define __ResetExecStatus(status) {\
   status.prev_active = status.active; \
   status.prev_suspended = status.suspended; \
   status.start = status.kill = status.active = status.suspended = 0; }
#define __DSZ(V) (--(V)<=0)
#define BASIC_TYPES_DEFINED
typedef int boolean;
typedef int integer;
typedef char* string;
#define CSIMUL_H_LOADED
typedef struct {char text[STRLEN];} symbolic;
extern void _boolean(boolean*, boolean);
extern boolean _eq_boolean(boolean, boolean);
extern boolean _ne_boolean(boolean, boolean);
extern boolean _cond_boolean(boolean ,boolean ,boolean);
extern char* _boolean_to_text(boolean);
extern int _check_boolean(char*);
extern void _text_to_boolean(boolean*, char*);
extern void _integer(integer*, integer);
extern boolean _eq_integer(integer, integer);
extern boolean _ne_integer(integer, integer);
extern integer _cond_integer(boolean ,integer ,integer);
extern char* _integer_to_text(integer);
extern int _check_integer(char*);
extern void _text_to_integer(integer*, char*);
extern void _string(string, string);
extern boolean _eq_string(string, string);
extern boolean _ne_string(string, string);
extern string _cond_string(boolean ,string ,string);
extern char* _string_to_text(string);
extern int _check_string(char*);
extern void _text_to_string(string, char*);
extern void _float(float*, float);
extern boolean _eq_float(float, float);
extern boolean _ne_float(float, float);
extern float _cond_float(boolean ,float ,float);
extern char* _float_to_text(float);
extern int _check_float(char*);
extern void _text_to_float(float*, char*);
extern void _double(double*, double);
extern boolean _eq_double(double, double);
extern boolean _ne_double(double, double);
extern double _cond_double(boolean ,double ,double);
extern char* _double_to_text(double);
extern int _check_double(char*);
extern void _text_to_double(double*, char*);
extern void _symbolic(symbolic*, symbolic);
extern boolean _eq_symbolic(symbolic, symbolic);
extern boolean _ne_symbolic(symbolic, symbolic);
extern symbolic _cond_symbolic(boolean ,symbolic ,symbolic);
extern char* _symbolic_to_text(symbolic);
extern int _check_symbolic(char*);
extern void _text_to_symbolic(symbolic*, char*);
extern char* __PredefinedTypeToText(int, char*);
#define _true 1
#define _false 0
#define __Lab2_GENERIC_TEST(TEST) return TEST;
typedef void (*__Lab2_APF)();
static __Lab2_APF *__Lab2_PActionArray;
static int **__Lab2_PCheckArray;
struct __SourcePoint {
int linkback;
int line;
int column;
int instance_index;
};
struct __InstanceEntry {
char *module_name;
int father_index;
char *dir_name;
char *file_name;
struct __SourcePoint source_point;
struct __SourcePoint end_point;
struct __SourcePoint instance_point;
};
struct __TaskEntry {
char *name;
int   nb_args_ref;
int   nb_args_val;
int  *type_codes_array;
struct __SourcePoint source_point;
};
struct __SignalEntry {
char *name;
int code;
int variable_index;
int present;
struct __SourcePoint source_point;
int number_of_emit_source_points;
struct __SourcePoint* emit_source_point_array;
int number_of_present_source_points;
struct __SourcePoint* present_source_point_array;
int number_of_access_source_points;
struct __SourcePoint* access_source_point_array;
};
struct __InputEntry {
char *name;
int hash;
char *type_name;
int is_a_sensor;
int type_code;
int multiple;
int signal_index;
int (*p_check_input)(char*);
void (*p_input_function)();
int present;
struct __SourcePoint source_point;
};
struct __ReturnEntry {
char *name;
int hash;
char *type_name;
int type_code;
int signal_index;
int exec_index;
int (*p_check_input)(char*);
void (*p_input_function)();
int present;
struct __SourcePoint source_point;
};
struct __ImplicationEntry {
int master;
int slave;
struct __SourcePoint source_point;
};
struct __ExclusionEntry {
int *exclusion_list;
struct __SourcePoint source_point;
};
struct __VariableEntry {
char *full_name;
char *short_name;
char *type_name;
int type_code;
int comment_kind;
int is_initialized;
char *p_variable;
char *source_name;
int written;
unsigned char written_in_transition;
unsigned char read_in_transition;
struct __SourcePoint source_point;
};
struct __ExecEntry {
int task_index;
int *var_indexes_array;
char **p_values_array;
struct __SourcePoint source_point;
};
struct __HaltEntry {
struct __SourcePoint source_point;
};
struct __NetEntry {
int known;
int value;
int number_of_source_points;
struct __SourcePoint* source_point_array;
};
struct __ModuleEntry {
char *version_id;
char *name;
int number_of_instances;
int number_of_tasks;
int number_of_signals;
int number_of_inputs;
int number_of_returns;
int number_of_sensors;
int number_of_outputs;
int number_of_locals;
int number_of_exceptions;
int number_of_implications;
int number_of_exclusions;
int number_of_variables;
int number_of_execs;
int number_of_halts;
int number_of_nets;
int number_of_states;
int state;
unsigned short *halt_list;
unsigned short *awaited_list;
unsigned short *emitted_list;
unsigned short *started_list;
unsigned short *killed_list;
unsigned short *suspended_list;
unsigned short *active_list;
int run_time_error_code;
int error_info;
void (*init)();
int (*run)();
int (*reset)();
char *(*show_variable)(int);
void (*set_variable)(int, char*, char*);
int (*check_value)(int, char*);
int (*execute_action)();
struct __InstanceEntry* instance_table;
struct __TaskEntry* task_table;
struct __SignalEntry* signal_table;
struct __InputEntry* input_table;
struct __ReturnEntry* return_table;
struct __ImplicationEntry* implication_table;
struct __ExclusionEntry* exclusion_table;
struct __VariableEntry* variable_table;
struct __ExecEntry* exec_table;
struct __HaltEntry* halt_table;
struct __NetEntry* net_table;
};

                      
/* EXTERN DECLARATIONS */

extern int __CheckVariables(int*);
extern void __ResetInput();
extern void __ResetExecs();
extern void __ResetVariables();
extern void __ResetVariableStatus();
extern void __AppendToList(unsigned short*, unsigned short);
extern void __ListCopy(unsigned short*, unsigned short**);
extern void __WriteVariable(int);
extern void __ResetVariable(int);
extern void __ResetModuleEntry();
extern void __ResetModuleEntryBeforeReaction();
extern void __ResetModuleEntryAfterReaction();
#ifndef _NO_EXTERN_DEFINITIONS
#endif

/* INITIALIZED CONSTANTS */

/* MEMORY ALLOCATION */

static boolean __Lab2_V0;
static boolean __Lab2_V1;
static boolean __Lab2_V2;
static boolean __Lab2_V3;
static integer __Lab2_V4;
static boolean __Lab2_V5;
static integer __Lab2_V6;
static integer __Lab2_V7;
static integer __Lab2_V8;
static integer __Lab2_V9;
static integer __Lab2_V10;
static integer __Lab2_V11;
static integer __Lab2_V12;

static unsigned short __Lab2_HaltList[4];
static unsigned short __Lab2_AwaitedList[10];
static unsigned short __Lab2_EmittedList[10];
static unsigned short __Lab2_StartedList[1];
static unsigned short __Lab2_KilledList[1];
static unsigned short __Lab2_SuspendedList[1];
static unsigned short __Lab2_ActiveList[1];
static unsigned short __Lab2_AllAwaitedList[10]={5,0,1,2,3,4};


/* INPUT FUNCTIONS */

void Lab2_I_START () {
__Lab2_V0 = _true;
}
void Lab2_IS_START () {
__Lab2_V0 = _true;
}
void Lab2_I_STOP () {
__Lab2_V1 = _true;
}
void Lab2_IS_STOP () {
__Lab2_V1 = _true;
}
void Lab2_I_LAP () {
__Lab2_V2 = _true;
}
void Lab2_IS_LAP () {
__Lab2_V2 = _true;
}
void Lab2_I_RESET () {
__Lab2_V3 = _true;
}
void Lab2_IS_RESET () {
__Lab2_V3 = _true;
}
void Lab2_I_C (integer __V) {
__WriteVariable(4);
__Lab2_V4 = __V;
__Lab2_V5 = _true;
}
void Lab2_IS_C (string __V) {
__WriteVariable(4);
_text_to_integer(&__Lab2_V4,__V);
__Lab2_V5 = _true;
}

/* FUNCTIONS RETURNING NUMBER OF EXEC */

int Lab2_number_of_execs () {
return (0);
}


/* AUTOMATON (STATE ACTION-TREES) */

/* ACTIONS */

/* PREDEFINED ACTIONS */

/* PRESENT SIGNAL TESTS */

static int __Lab2_A1 () {
__Lab2_GENERIC_TEST(__Lab2_V0);
}
static int __Lab2_Check1 [] = {1,0,0};
static int __Lab2_A2 () {
__Lab2_GENERIC_TEST(__Lab2_V1);
}
static int __Lab2_Check2 [] = {1,0,0};
static int __Lab2_A3 () {
__Lab2_GENERIC_TEST(__Lab2_V2);
}
static int __Lab2_Check3 [] = {1,0,0};
static int __Lab2_A4 () {
__Lab2_GENERIC_TEST(__Lab2_V3);
}
static int __Lab2_Check4 [] = {1,0,0};
static int __Lab2_A5 () {
__Lab2_GENERIC_TEST(__Lab2_V5);
}
static int __Lab2_Check5 [] = {1,0,0};

/* OUTPUT ACTIONS */

static void __Lab2_A6 () {
#ifdef __OUTPUT
Lab2_O_HH(__Lab2_V6);
#endif
__AppendToList(__Lab2_EmittedList,5);
}
static int __Lab2_Check6 [] = {1,0,0};
static void __Lab2_A7 () {
#ifdef __OUTPUT
Lab2_O_MM(__Lab2_V7);
#endif
__AppendToList(__Lab2_EmittedList,6);
}
static int __Lab2_Check7 [] = {1,0,0};
static void __Lab2_A8 () {
#ifdef __OUTPUT
Lab2_O_SS(__Lab2_V8);
#endif
__AppendToList(__Lab2_EmittedList,7);
}
static int __Lab2_Check8 [] = {1,0,0};
static void __Lab2_A9 () {
#ifdef __OUTPUT
Lab2_O_DD(__Lab2_V9);
#endif
__AppendToList(__Lab2_EmittedList,8);
}
static int __Lab2_Check9 [] = {1,0,0};

/* ASSIGNMENTS */

static void __Lab2_A10 () {
__Lab2_V0 = _false;
}
static int __Lab2_Check10 [] = {1,0,1,0};
static void __Lab2_A11 () {
__Lab2_V1 = _false;
}
static int __Lab2_Check11 [] = {1,0,1,1};
static void __Lab2_A12 () {
__Lab2_V2 = _false;
}
static int __Lab2_Check12 [] = {1,0,1,2};
static void __Lab2_A13 () {
__Lab2_V3 = _false;
}
static int __Lab2_Check13 [] = {1,0,1,3};
static void __Lab2_A14 () {
__Lab2_V5 = _false;
}
static int __Lab2_Check14 [] = {1,0,1,5};
static void __Lab2_A15 () {
__Lab2_V4 = 0;
}
static int __Lab2_Check15 [] = {1,0,1,4};
static void __Lab2_A16 () {
__Lab2_V6 = 0;
}
static int __Lab2_Check16 [] = {1,0,1,6};
static void __Lab2_A17 () {
__Lab2_V7 = 0;
}
static int __Lab2_Check17 [] = {1,0,1,7};
static void __Lab2_A18 () {
__Lab2_V8 = 0;
}
static int __Lab2_Check18 [] = {1,0,1,8};
static void __Lab2_A19 () {
__Lab2_V9 = 0;
}
static int __Lab2_Check19 [] = {1,0,1,9};
static void __Lab2_A20 () {
__Lab2_V10 = 0;
}
static int __Lab2_Check20 [] = {1,0,1,10};
static void __Lab2_A21 () {
__Lab2_V10 = __Lab2_V4;
}
static int __Lab2_Check21 [] = {1,1,4,1,10};
static void __Lab2_A22 () {
__Lab2_V4 = __Lab2_V10+1;
}
static int __Lab2_Check22 [] = {1,1,10,1,4};
static void __Lab2_A23 () {
__Lab2_V11 = 100;
}
static int __Lab2_Check23 [] = {1,0,1,11};
static void __Lab2_A24 () {
__Lab2_V12 = 0;
}
static int __Lab2_Check24 [] = {1,0,1,12};
static void __Lab2_A25 () {
__Lab2_V12 = __Lab2_V8;
}
static int __Lab2_Check25 [] = {1,1,8,1,12};
static void __Lab2_A26 () {
__Lab2_V8 = __Lab2_V12+1;
}
static int __Lab2_Check26 [] = {1,1,12,1,8};

/* PROCEDURE CALLS */

/* CONDITIONS */

/* DECREMENTS */

static int __Lab2_A27 () {
__Lab2_GENERIC_TEST(__DSZ(__Lab2_V11));
}
static int __Lab2_Check27 [] = {1,1,11,1,11};

/* START ACTIONS */

/* KILL ACTIONS */

/* SUSPEND ACTIONS */

/* ACTIVATE ACTIONS */

/* WRITE ARGS ACTIONS */

/* RESET ACTIONS */

/* ACTION SEQUENCES */


static int *__Lab2_CheckArray[] = {
0,
__Lab2_Check1,
__Lab2_Check2,
__Lab2_Check3,
__Lab2_Check4,
__Lab2_Check5,
__Lab2_Check6,
__Lab2_Check7,
__Lab2_Check8,
__Lab2_Check9,
__Lab2_Check10,
__Lab2_Check11,
__Lab2_Check12,
__Lab2_Check13,
__Lab2_Check14,
__Lab2_Check15,
__Lab2_Check16,
__Lab2_Check17,
__Lab2_Check18,
__Lab2_Check19,
__Lab2_Check20,
__Lab2_Check21,
__Lab2_Check22,
__Lab2_Check23,
__Lab2_Check24,
__Lab2_Check25,
__Lab2_Check26,
__Lab2_Check27
};
static int **__Lab2_PCheckArray =  __Lab2_CheckArray;

/* INIT FUNCTION */

#ifndef NO_INIT
void Lab2_initialize () {
}
#endif

/* SHOW VARIABLE FUNCTION */

char* __Lab2_show_variable (int __V) {
extern struct __VariableEntry __Lab2_VariableTable[];
struct __VariableEntry* p_var = &__Lab2_VariableTable[__V];
if (p_var->type_code < 0) {return __PredefinedTypeToText(p_var->type_code, p_var->p_variable);
} else {
switch (p_var->type_code) {
default: return 0;
}
}
}

/* SET VARIABLE FUNCTION */

static void __Lab2_set_variable(int __Type, char* __pVar, char* __Text) {
}

/* CHECK VALUE FUNCTION */

static int __Lab2_check_value (int __Type, char* __Text) {
return 0;
}

/* SIMULATION TABLES */

struct __InstanceEntry __Lab2_InstanceTable [] = {
{"Lab2",0,"/home/student/workspace/Lab2//src","Lab2.strl",{1,31,1,0},{1,44,1,0},{0,0,0,0}},
};

struct __SignalEntry __Lab2_SignalTable [] = {
{"START",33,0,0,{1,32,8,0},0,(void*) NULL,0,(void*) NULL,0,(void*) NULL},
{"STOP",33,0,0,{1,32,15,0},0,(void*) NULL,0,(void*) NULL,0,(void*) NULL},
{"LAP",33,0,0,{1,32,21,0},0,(void*) NULL,0,(void*) NULL,0,(void*) NULL},
{"RESET",33,0,0,{1,32,26,0},0,(void*) NULL,0,(void*) NULL,0,(void*) NULL},
{"C",1,4,0,{1,32,32,0},0,(void*) NULL,0,(void*) NULL,0,(void*) NULL},
{"HH",2,6,0,{1,33,9,0},0,(void*) NULL,0,(void*) NULL,0,(void*) NULL},
{"MM",2,7,0,{1,33,27,0},0,(void*) NULL,0,(void*) NULL,0,(void*) NULL},
{"SS",2,8,0,{1,34,6,0},0,(void*) NULL,0,(void*) NULL,0,(void*) NULL},
{"DD",2,9,0,{1,34,24,0},0,(void*) NULL,0,(void*) NULL,0,(void*) NULL}};

struct __InputEntry __Lab2_InputTable [] = {
{"START",95,0,0,-1,0,0,0,Lab2_IS_START,0,{1,32,8,0}},
{"STOP",23,0,0,-1,0,1,0,Lab2_IS_STOP,0,{1,32,15,0}},
{"LAP",19,0,0,-1,0,2,0,Lab2_IS_LAP,0,{1,32,21,0}},
{"RESET",84,0,0,-1,0,3,0,Lab2_IS_RESET,0,{1,32,26,0}},
{"C",67,"integer",0,-3,0,4,_check_integer,Lab2_IS_C,0,{1,32,32,0}}};

struct __VariableEntry __Lab2_VariableTable [] = {
{"__Lab2_V0","V0","boolean",-2,2,0,(char*)&__Lab2_V0,"START",0,0,0,{1,32,8,0}},
{"__Lab2_V1","V1","boolean",-2,2,0,(char*)&__Lab2_V1,"STOP",0,0,0,{1,32,15,0}},
{"__Lab2_V2","V2","boolean",-2,2,0,(char*)&__Lab2_V2,"LAP",0,0,0,{1,32,21,0}},
{"__Lab2_V3","V3","boolean",-2,2,0,(char*)&__Lab2_V3,"RESET",0,0,0,{1,32,26,0}},
{"__Lab2_V4","V4","integer",-3,1,0,(char*)&__Lab2_V4,"C",0,0,0,{1,32,32,0}},
{"__Lab2_V5","V5","boolean",-2,2,0,(char*)&__Lab2_V5,"C",0,0,0,{1,32,32,0}},
{"__Lab2_V6","V6","integer",-3,1,0,(char*)&__Lab2_V6,"HH",0,0,0,{1,33,9,0}},
{"__Lab2_V7","V7","integer",-3,1,0,(char*)&__Lab2_V7,"MM",0,0,0,{1,33,27,0}},
{"__Lab2_V8","V8","integer",-3,1,0,(char*)&__Lab2_V8,"SS",0,0,0,{1,34,6,0}},
{"__Lab2_V9","V9","integer",-3,1,0,(char*)&__Lab2_V9,"DD",0,0,0,{1,34,24,0}},
{"__Lab2_V10","V10","integer",-3,10,0,(char*)&__Lab2_V10,"C",0,0,0,{1,32,32,0}},
{"__Lab2_V11","V11","integer",-3,3,0,(char*)&__Lab2_V11,"0",0,0,0,{1,41,9,0}},
{"__Lab2_V12","V12","integer",-3,10,0,(char*)&__Lab2_V12,"SS",0,0,0,{1,34,6,0}}
};

struct __HaltEntry __Lab2_HaltTable [] = {
{{1,44,1,0}},
{{1,37,3,0}},
{{1,41,3,0}}
};


static void __Lab2__reset_input () {
__Lab2_V0 = _false;
__Lab2_V1 = _false;
__Lab2_V2 = _false;
__Lab2_V3 = _false;
__Lab2_V5 = _false;
}


/* MODULE DATA FOR SIMULATION */

int Lab2();
int Lab2_reset();

static struct __ModuleEntry __Lab2_ModuleData = {
"Simulation interface release 5","Lab2",
1,0,9,5,0,0,4,0,0,0,0,13,0,3,0,0,0,
__Lab2_HaltList,
__Lab2_AwaitedList,
__Lab2_EmittedList,
__Lab2_StartedList,
__Lab2_KilledList,
__Lab2_SuspendedList,
__Lab2_ActiveList,
0,0,
Lab2_initialize,Lab2,Lab2_reset,
__Lab2_show_variable,__Lab2_set_variable,__Lab2_check_value,0,
__Lab2_InstanceTable,
0,
__Lab2_SignalTable,__Lab2_InputTable,0,
0,0,
__Lab2_VariableTable,
0,
__Lab2_HaltTable,
0};

/* REDEFINABLE BIT TYPE */

#ifndef __SSC_BIT_TYPE_DEFINED
typedef char __SSC_BIT_TYPE;
#endif

/* REGISTER VARIABLES */

static __SSC_BIT_TYPE __Lab2_R[3] = {_true,
 _false,
 _false};

/* AUTOMATON ENGINE */

int Lab2 () {
/* AUXILIARY VARIABLES */

static __SSC_BIT_TYPE E[8];

__Lab2_ModuleData.awaited_list = __Lab2_AwaitedList;
__ResetModuleEntryBeforeReaction();
E[0] = __Lab2_R[0]&&!((__CheckVariables(__Lab2_CheckArray[5]),
#ifdef TRACE_ACTION
fprintf(stderr, "test 5\n"),
#endif
__Lab2_A5()));
if (E[0]) {
__CheckVariables(__Lab2_CheckArray[15]);__Lab2_A15();
#ifdef TRACE_ACTION
fprintf(stderr, "__Lab2_A15\n");
#endif
}
if (__Lab2_R[0]) {
__CheckVariables(__Lab2_CheckArray[20]);__Lab2_A20();
#ifdef TRACE_ACTION
fprintf(stderr, "__Lab2_A20\n");
#endif
}
if (__Lab2_R[0]) {
__CheckVariables(__Lab2_CheckArray[16]);__Lab2_A16();
#ifdef TRACE_ACTION
fprintf(stderr, "__Lab2_A16\n");
#endif
}
if (__Lab2_R[0]) {
__CheckVariables(__Lab2_CheckArray[17]);__Lab2_A17();
#ifdef TRACE_ACTION
fprintf(stderr, "__Lab2_A17\n");
#endif
}
if (__Lab2_R[0]) {
__CheckVariables(__Lab2_CheckArray[18]);__Lab2_A18();
#ifdef TRACE_ACTION
fprintf(stderr, "__Lab2_A18\n");
#endif
}
if (__Lab2_R[0]) {
__CheckVariables(__Lab2_CheckArray[24]);__Lab2_A24();
#ifdef TRACE_ACTION
fprintf(stderr, "__Lab2_A24\n");
#endif
}
if (__Lab2_R[0]) {
__CheckVariables(__Lab2_CheckArray[19]);__Lab2_A19();
#ifdef TRACE_ACTION
fprintf(stderr, "__Lab2_A19\n");
#endif
}
E[1] = __Lab2_R[0]||(__Lab2_R[1]&&!(__Lab2_R[0]));
E[2] = (__CheckVariables(__Lab2_CheckArray[5]),
#ifdef TRACE_ACTION
fprintf(stderr, "test 5\n"),
#endif
__Lab2_A5())||E[1];
if (E[2]) {
__AppendToList(__Lab2_EmittedList,4);
}
if (E[1]) {
__CheckVariables(__Lab2_CheckArray[22]);__Lab2_A22();
#ifdef TRACE_ACTION
fprintf(stderr, "__Lab2_A22\n");
#endif
}
E[3] = __Lab2_R[2]&&!(__Lab2_R[0]);
E[4] = E[3]&&E[2];
E[5] = E[4]&&(__CheckVariables(__Lab2_CheckArray[27]),
#ifdef TRACE_ACTION
fprintf(stderr, "test 27\n"),
#endif
__Lab2_A27());
if (E[5]) {
__AppendToList(__Lab2_EmittedList,7);
}
if (E[5]) {
__CheckVariables(__Lab2_CheckArray[26]);__Lab2_A26();
#ifdef TRACE_ACTION
fprintf(stderr, "__Lab2_A26\n");
#endif
}
E[6] = __Lab2_R[0]||E[5];
if (E[6]) {
__CheckVariables(__Lab2_CheckArray[23]);__Lab2_A23();
#ifdef TRACE_ACTION
fprintf(stderr, "__Lab2_A23\n");
#endif
}
E[3] = E[6]||(__Lab2_R[2]&&((E[4]&&!(E[5]))||(E[3]&&!(E[2]))));
E[4] = __Lab2_R[1]||__Lab2_R[2];
E[4] = (E[1]||E[3])&&((E[4]&&!(__Lab2_R[1]))||E[1])&&((E[4]&&!(__Lab2_R[2]))||E[3]);
if (E[2]&&E[4]) {
__CheckVariables(__Lab2_CheckArray[21]);__Lab2_A21();
#ifdef TRACE_ACTION
fprintf(stderr, "__Lab2_A21\n");
#endif
}
if (!(_true)) {
__CheckVariables(__Lab2_CheckArray[6]);__Lab2_A6();
#ifdef TRACE_ACTION
fprintf(stderr, "__Lab2_A6\n");
#endif
}
if (!(_true)) {
__CheckVariables(__Lab2_CheckArray[7]);__Lab2_A7();
#ifdef TRACE_ACTION
fprintf(stderr, "__Lab2_A7\n");
#endif
}
if (E[5]) {
__CheckVariables(__Lab2_CheckArray[8]);__Lab2_A8();
#ifdef TRACE_ACTION
fprintf(stderr, "__Lab2_A8\n");
#endif
}
if (E[5]&&E[4]) {
__CheckVariables(__Lab2_CheckArray[25]);__Lab2_A25();
#ifdef TRACE_ACTION
fprintf(stderr, "__Lab2_A25\n");
#endif
}
if (!(_true)) {
__CheckVariables(__Lab2_CheckArray[9]);__Lab2_A9();
#ifdef TRACE_ACTION
fprintf(stderr, "__Lab2_A9\n");
#endif
}
E[7] = !(_true);
__Lab2_R[0] = !(_true);
__Lab2_R[1] = E[1];
if (__Lab2_R[1]) { __AppendToList(__Lab2_HaltList,1); }
__Lab2_R[2] = E[3];
if (__Lab2_R[2]) { __AppendToList(__Lab2_HaltList,2); }
if (!E[4]) { __AppendToList(__Lab2_HaltList,0); }
__ResetModuleEntryAfterReaction();
__Lab2_ModuleData.awaited_list = __Lab2_AllAwaitedList;
__Lab2__reset_input();
return E[4];
}

/* AUTOMATON RESET */

int Lab2_reset () {
__Lab2_ModuleData.awaited_list = __Lab2_AwaitedList;
__ResetModuleEntry();
__Lab2_ModuleData.awaited_list = __Lab2_AllAwaitedList;
__Lab2_ModuleData.state = 0;
__Lab2_R[0] = _true;
__Lab2_R[1] = _false;
__Lab2_R[2] = _false;
__Lab2__reset_input();
return 0;
}
char* CompilationType = "Compiled Sorted Equations";

int __NumberOfModules = 1;
struct __ModuleEntry* __ModuleTable[] = {
&__Lab2_ModuleData
};

/* sscc : C CODE OF SORTED EQUATIONS Lab3 - INLINE MODE */

/* AUXILIARY DECLARATIONS */

#ifndef STRLEN
#define STRLEN 81
#endif
#define _COND(A,B,C) ((A)?(B):(C))
#ifdef TRACE_ACTION
#include <stdio.h>
#endif
#ifndef NULL
#define NULL ((char*)0)
#endif

#ifndef __EXEC_STATUS_H_LOADED
#define __EXEC_STATUS_H_LOADED

typedef struct {
unsigned int start:1;
unsigned int kill:1;
unsigned int active:1;
unsigned int suspended:1;
unsigned int prev_active:1;
unsigned int prev_suspended:1;
unsigned int exec_index;
unsigned int task_exec_index;
void (*pStart)();
void (*pRet)();
} __ExecStatus;

#endif
#define __ResetExecStatus(status) {\
   status.prev_active = status.active; \
   status.prev_suspended = status.suspended; \
   status.start = status.kill = status.active = status.suspended = 0; }
#define __DSZ(V) (--(V)<=0)
#define BASIC_TYPES_DEFINED
typedef int boolean;
typedef int integer;
typedef char* string;
#define _true 1
#define _false 0
#define __Lab3_GENERIC_TEST(TEST) return TEST;
typedef void (*__Lab3_APF)();
static __Lab3_APF *__Lab3_PActionArray;

                  
/* EXTERN DECLARATIONS */

#ifndef _NO_EXTERN_DEFINITIONS
#endif

/* INITIALIZED CONSTANTS */

/* MEMORY ALLOCATION */

static boolean __Lab3_V0;
static boolean __Lab3_V1;
static integer __Lab3_V2;


/* INPUT FUNCTIONS */

void Lab3_I_MANUAL_TRIGGER () {
__Lab3_V0 = _true;
}
void Lab3_I_MAYBE_CRITICAL () {
__Lab3_V1 = _true;
}

/* ACTIONS */

/* PREDEFINED ACTIONS */

/* PRESENT SIGNAL TESTS */

#define __Lab3_A1 \
__Lab3_V0
#define __Lab3_A2 \
__Lab3_V1

/* OUTPUT ACTIONS */

#define __Lab3_A3 \
Lab3_O_RELEASE_PARACHUTE()

/* ASSIGNMENTS */

#define __Lab3_A4 \
__Lab3_V0 = _false
#define __Lab3_A5 \
__Lab3_V1 = _false
#define __Lab3_A6 \
__Lab3_V2 = 2

/* PROCEDURE CALLS */

/* CONDITIONS */

/* DECREMENTS */

#define __Lab3_A7 \
__DSZ(__Lab3_V2)

/* START ACTIONS */

/* KILL ACTIONS */

/* SUSPEND ACTIONS */

/* ACTIVATE ACTIONS */

/* WRITE ARGS ACTIONS */

/* RESET ACTIONS */

/* ACTION SEQUENCES */

/* FUNCTIONS RETURNING NUMBER OF EXEC */

int Lab3_number_of_execs () {
return (0);
}


/* AUTOMATON (STATE ACTION-TREES) */



static void __Lab3__reset_input () {
__Lab3_V0 = _false;
__Lab3_V1 = _false;
}

/* REDEFINABLE BIT TYPE */

#ifndef __SSC_BIT_TYPE_DEFINED
typedef char __SSC_BIT_TYPE;
#endif

/* REGISTER VARIABLES */

static __SSC_BIT_TYPE __Lab3_R[5] = {_true,
 _false,
 _false,
 _false,
 _false};

/* AUTOMATON ENGINE */

int Lab3 () {
/* AUXILIARY VARIABLES */

static __SSC_BIT_TYPE E[16];
E[0] = __Lab3_R[0]&&!((
#ifdef TRACE_ACTION
fprintf(stderr, "test 1\n"),
#endif
__Lab3_A1));
E[1] = __Lab3_R[1]&&!(__Lab3_R[0]);
E[2] = E[1]&&(
#ifdef TRACE_ACTION
fprintf(stderr, "test 2\n"),
#endif
__Lab3_A2);
E[3] = E[2]&&(
#ifdef TRACE_ACTION
fprintf(stderr, "test 7\n"),
#endif
__Lab3_A7);
E[4] = __Lab3_R[2]&&!(__Lab3_R[0]);
E[5] = E[4]&&(
#ifdef TRACE_ACTION
fprintf(stderr, "test 1\n"),
#endif
__Lab3_A1);
E[6] = E[3]||E[5];
E[7] = E[0]&&E[6];
E[8] = __Lab3_R[1]||__Lab3_R[2]||__Lab3_R[3];
E[9] = (E[8]&&!(__Lab3_R[1]))||E[3];
if (E[0]) {
__Lab3_A6;
#ifdef TRACE_ACTION
fprintf(stderr, "__Lab3_A6\n");
#endif
}
E[1] = E[1]&&!((
#ifdef TRACE_ACTION
fprintf(stderr, "test 2\n"),
#endif
__Lab3_A2));
E[1] = E[0]||(__Lab3_R[1]&&((E[2]&&!(E[3]))||E[1]));
E[2] = E[9]||E[1];
E[10] = (E[8]&&!(__Lab3_R[2]))||E[5];
E[4] = E[4]&&!((
#ifdef TRACE_ACTION
fprintf(stderr, "test 1\n"),
#endif
__Lab3_A1));
E[4] = E[0]||(__Lab3_R[2]&&E[4]);
E[11] = E[10]||E[4];
E[12] = __Lab3_R[3]&&!(__Lab3_R[0]);
E[13] = (E[8]&&!(__Lab3_R[3]))||E[12];
E[6] = E[0]&&!(E[6]);
E[14] = E[13]||E[6];
E[7] = E[7]&&E[2]&&E[11]&&(E[14]||E[7]);
E[15] = __Lab3_R[0]&&(
#ifdef TRACE_ACTION
fprintf(stderr, "test 1\n"),
#endif
__Lab3_A1);
E[15] = E[7]||((E[3]||E[5]||E[12])&&E[9]&&E[10]&&E[13])||(__Lab3_R[4]&&!(__Lab3_R[0]))||E[15];
if (E[15]) {
__Lab3_A3;
#ifdef TRACE_ACTION
fprintf(stderr, "__Lab3_A3\n");
#endif
}
E[13] = !(_true);
E[14] = E[15]||((E[1]||E[4]||E[6])&&E[2]&&E[11]&&E[14]);
E[8] = __Lab3_R[4]||E[8];
__Lab3_R[1] = E[1]&&!(E[7]);
__Lab3_R[2] = E[4]&&!(E[7]);
__Lab3_R[3] = E[6]&&!(E[7]);
__Lab3_R[0] = !(_true);
__Lab3_R[4] = E[15];
__Lab3__reset_input();
return E[14];
}

/* AUTOMATON RESET */

int Lab3_reset () {
__Lab3_R[0] = _true;
__Lab3_R[1] = _false;
__Lab3_R[2] = _false;
__Lab3_R[3] = _false;
__Lab3_R[4] = _false;
__Lab3__reset_input();
return 0;
}

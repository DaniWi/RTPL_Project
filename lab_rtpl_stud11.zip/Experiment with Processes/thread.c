/**
 * @file thread.c
 * @brief process creates new threads/light-weight processes
 * @author Martin Becker <becker@rcs.ei.tum.de>
 * @date 2015-December-12
 */

#define _GNU_SOURCE
#include <fcntl.h> // O_RDONLY
#include <sched.h> // clone
#include <stdio.h> // printf
#include <unistd.h> // exit
#include <stdlib.h> // malloc

int variable, fd; // visible for both main() and thread_start_function() 

#define STACKSIZE 16384

void mypause ( const char *text ) { 
    printf ( text );
    fflush ( stdout );
    getchar();
} 

thread_start_function() {    
    /* Executed only by the child */
    sleep(1);
    printf("C: my process id is %d\n", getpid());
    variable = 42;
    printf("C: changed the variable to: %d\n", variable);
    close(fd);
    printf("C: closed the file.\n");
    mypause("C: paused (press key)\n");
    printf("C: exit\n");
    _exit(0);
}

int main(int argc, char *argv[]) {
    void **child_stack;     
    int pid;
    char ch;

    // shared resources:
    variable = 9;
    fd = open("test.file", O_RDONLY);

    printf("P: my process id is %d\n", getpid());

    // create new light-weight process:
    child_stack = (void **) malloc(STACKSIZE);
    if (!child_stack) {
        printf("ERROR allocating stack for child\n");
        exit (1);
    }
    child_stack += STACKSIZE - 1; // stack grows downards; set ptr to highest address in allocated mem
    pid = clone(thread_start_function, child_stack, CLONE_VM|CLONE_FILES, NULL);

    // executed only by the parent:
    printf("P: created child\n");
    mypause("P: paused (press key)\n");

    printf("P: The variable is now: %d\n", variable);
    if (read(fd, &ch, 1) < 0) {
        perror("P: READ failed");
        return(1);
    }
    printf("P: Read from the file: %s\n", &ch);
    printf("P: exit\n");
    return(0);
}





/**
 * @file main.c
 * @brief This program consists of one (heavy-weight) process, which makes a full copy of itself, such that there are two processes in effect. The new process is the child of the original one, but has its own resources (memory space, etc.)
 * @author Martin Becker <becker@rcs.ei.tum.de>
 * @date 2015-December-12
 */

#include <fcntl.h> // O_RDONLY
#include <sched.h> // fork
#include <stdio.h> // printd

int fd, variable;

void mypause ( const char *text ) { 
    printf ( text );
    fflush ( stdout );
    getchar();
} 


int main(int argc, char *argv[]) {
   
    pid_t chpid;
    int status;
    char ch;
   
    printf("P: my process id is %d\n", getpid());

    // *not*-shared resources:
    variable = 9;
    fd = open("test.file", O_RDONLY);

    // create a new process
    chpid = fork(); // at this point, we get two parallel execution flows
    if (chpid != 0) { 
        /* Executed only by the parent */
        printf("P: created child\n");
        wait(&status); // go sleeping until child terminates
    }else {
        /* Executed only by the child */
        printf("C: my process id is %d\n", getpid());
        variable = 42;
        close(fd);
        printf("C: changed the variable to: %d\n", variable);
        printf("C: closed the file.\n");
        mypause("C: paused (press key)\n");
        printf("C: exit\n");
        return(0);
    }
    // ony reachable by parent/original process:
    sleep(1); // to make the output more clear
    printf("P: The variable is now: %d\n", variable);
    if (read(fd, &ch, 1) < 0) { // will not fail, since child had no access to fd
        perror("P: READ failed");
        return(1);
    }
    printf("P: Read from the file: %s\n", &ch);
    printf("P: exit\n");
    return(0);
}



